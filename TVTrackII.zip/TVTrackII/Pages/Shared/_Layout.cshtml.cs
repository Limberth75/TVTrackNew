using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TVTrackII.Pages.Shared
{
    public class _LayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
