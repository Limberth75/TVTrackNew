﻿using System.Collections.Generic;

namespace TVTrackII.Models
{
    public class Contenido
    {
        public int Id { get; set; }
        public string Titulo { get; set; } = string.Empty;
        public int VecesVisto { get; set; } = 0;

        public ICollection<Calificacion>? Calificaciones { get; set; }
    }
}
