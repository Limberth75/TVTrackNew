using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TVTrackII.Pages
{
    public class ContenidoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
