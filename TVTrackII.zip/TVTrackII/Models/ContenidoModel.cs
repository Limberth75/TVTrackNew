﻿using System;

namespace TVTrackII.Models
{
    public class ContenidoModel
    {
        public string Titulo { get; set; } = string.Empty;
        public string Genero { get; set; } = string.Empty;
        public DateTime Fecha { get; set; }
    }
}
