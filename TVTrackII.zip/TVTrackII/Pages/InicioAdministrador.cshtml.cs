using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TVTrackII.Pages
{
    public class InicioAdministradorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
