using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TVTrackII.Data;
using TVTrackII.Models;

namespace TVTrackII.Pages
{
    public class LoginModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public LoginModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public string Correo { get; set; } = string.Empty;

        [BindProperty]
        public string Contrasena { get; set; } = string.Empty;

        public string MensajeError { get; set; } = string.Empty;

        public IActionResult OnPost()
        {
            var correoNormalizado = Correo.Trim().ToLower();

            var usuario = _context.Usuarios
                .FirstOrDefault(u => u.Correo.Trim().ToLower() == correoNormalizado
                                  && u.Contrasena == Contrasena);

            if (usuario == null)
            {
                MensajeError = "Credenciales inv�lidas.";
                return Page();
            }

            // Redirigir seg�n el rol
            if (usuario.Rol == "Administrador")
                return RedirectToPage("/Usuarios/Index");
            else
                return RedirectToPage("/Inicio");
        }
    }
}
