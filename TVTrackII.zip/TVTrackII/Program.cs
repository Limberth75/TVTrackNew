using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using TVTrackII.Data;
using TVTrackII.Models;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);

// Activar Razor Pages
builder.Services.AddRazorPages();

// Configurar conexi�n a base de datos SQL Server
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Activar uso de Session
builder.Services.AddSession();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseStaticFiles();

app.UseRouting();

// Habilitar Session
app.UseSession();

app.MapRazorPages();

// Crear autom�ticamente usuario Admin y 100 usuarios normales
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // Crear usuario Admin si no existe
    if (!context.Usuarios.Any(u => u.Nombre == "Admin"))
    {
        context.Usuarios.Add(new Usuario
        {
            Nombre = "Admin",
            Correo = "admin@admin.com",
            Contrasena = "admin",
            Rol = "Administrador"
        });

        context.SaveChanges();
    }

    // Crear hasta 100 usuarios normales si no existen
    int cantidadActual = context.Usuarios.Count(u => u.Rol == "Usuario");
    int cantidadFaltante = 100 - cantidadActual;

    if (cantidadFaltante > 0)
    {
        for (int i = cantidadActual + 1; i <= 100; i++)
        {
            context.Usuarios.Add(new Usuario
            {
                Nombre = $"Usuario{i}",
                Correo = $"usuario{i}@hotmail.com",
                Contrasena = "1234",
                Rol = "Usuario"
            });
        }

        context.SaveChanges();
    }
}

// Redireccionar a Login por defecto
app.MapGet("/", context =>
{
    context.Response.Redirect("/Login");
    return Task.CompletedTask;
});

app.Run();
